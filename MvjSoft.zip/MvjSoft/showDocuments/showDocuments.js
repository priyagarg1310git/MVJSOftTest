import { LightningElement,api,wire } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import deleteDocData from '@salesforce/apex/DocumentSearchController.deleteDocData';
import getDocData from '@salesforce/apex/DocumentSearchController.getDocData';
import { refreshApex } from '@salesforce/apex';
import { notifyRecordUpdateAvailable } from 'lightning/uiRecordApi';
import updateDocument from '@salesforce/apex/DocumentSearchController.updateDocument';

const cols = [
        {label:'Name', fieldName:'Document_Name__c' , type:'text',editable:true} ,
        {label:'Document Version', fieldName:'Document_Version__c' , type:'text'} ,
        {label:'Document Category', fieldName:'Document_Category__c' , type:'text'},
        {label:'Delete',type: "button-icon", typeAttributes: {iconName: "utility:delete", name: "delete", iconClass: "slds-icon-text-error"}},             
]

export default class ShowDocuments extends LightningElement {
    cols = cols;
    @api searchKey;
    docInfo=[];
    draftValues = [];
    hasData =false;
    refreshData;


// wired method to fetch all the records where name like searchKey
  @wire(getDocData, { textkey: '$searchKey' })
    docData({ error, data }) {
      if (data) {
          if(data != null){ // if data available
            console.log('Data', data);
            this.handleHasData();
            this.docInfo = data;
          }else{ // if data is null
            this.dispatchEvent(
            new ShowToastEvent({
                title: 'No Record Found',
                message: '',
                variant: 'error',
                mode: 'dismissable'
            })
         );
        }   
    } else if (error) { // for error
         console.error('Error:', error);
         this.dispatchEvent(
            new ShowToastEvent({
                title: 'No Record Found',
                message: '',
                variant: 'error',
                mode: 'dismissable'
            })
         );
        this.docInfo = null;
      }
    }

    handleHasData(){ 
       this.hasData = !this.hasData; 
    }
    
    handleRowAction(event) { // on selection of delete
		if (event.detail.action.name === "delete") {
			this.deleteSelectedRow(event.detail.row);
		}
	}

// method to delete the row and record using Apex Controller
    async deleteSelectedRow(deleteRow) { 
        let deletedData = JSON.parse(JSON.stringify(deleteRow));
        let deletedId = deletedData.Id;
        deleteDocData({removeDocIds:deletedId}).then(result =>{
            if(result){
                const evt = new ShowToastEvent({
                    title: 'Success Message',
                    message: 'Record deleted successfully ',
                    variant: 'success',
                    mode:'dismissible'
                });
                this.dispatchEvent(evt);
             refreshApex(this.docInfo);
            }else{
               this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error occured while deleting record',
                    message: '',
                    variant: 'error',
                    mode:'dismissible'
                }) 
            ); 
            }               
            }).catch(error => {
                this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error occured while deleting record',
                    message: '',
                    variant: 'error',
                    mode:'dismissible'
                }) 
            );              
        });
    }


// when Name is updated then draft a value in table and update the record using Apex Controller
    async handleSave(event) {
    const updatedFields = event.detail.draftValues;
    // Prepare the record IDs for notifyRecordUpdateAvailable()
    const notifyChangeIds = updatedFields.map(row => { return { "recordId": row.Id } });

    try {
        // Pass edited fields to the updateDocument Apex controller
        const result = await updateDocument({data: updatedFields});
        console.log(JSON.stringify("Apex update result: "+ result));
        this.dispatchEvent(
            new ShowToastEvent({
                title: 'Success',
                message: 'Document updated',
                variant: 'success'
            })
        );

        // Refresh LDS cache and wires
        notifyRecordUpdateAvailable(notifyChangeIds);

        // Display fresh data in the datatable
         refreshApex(this.docInfo);
            // Clear all draft values in the datatable
            this.draftValues = [];
   } catch(error) {
           this.dispatchEvent(
               new ShowToastEvent({
                   title: 'Error updating or refreshing records',
                   message: '',
                   variant: 'error'
               })
         );
    }
}


}