import { LightningElement} from 'lwc';
export default class LiveSearch extends LightningElement {

    searchKey;
    hasData = false;

// handle input
    handleInput(event){
        this.searchKey = event.target.value;
    }


// on click of search button
    handleSearch(){
      this.handleHasData(); 
    }
    handleHasData(){
       this.hasData = !this.hasData; 
    }

}